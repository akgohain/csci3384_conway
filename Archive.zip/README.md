# csci3384_conway

[lifewiki](https://conwaylife.com/wiki/)
[good aggregate](https://www.comunidad.escom.ipn.mx/genaro/Cellular_Automata_Repository/Life.html)
[object list](https://wwwhomes.uni-bielefeld.de/achim/freq_top_life.html)